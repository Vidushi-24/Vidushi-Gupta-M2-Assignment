import {Component} from '@angular/core'
import {Employee} from './Employee';


@Component({
    selector:'emp-app',
    templateUrl: `./app.employee.html`
})
export class EmployeeComponent{
    

    empId:number;
    employeeName:string;
    employeePrice:number;
    employeeDescription:string;

    
    Id:number;
    Name:string;
    Price:number;
    Description:string;


    employeedata:Employee[]=[
        {empId:101,employeeName:"Vidushi",employeePrice:21000,employeeDescription:"Java"},
        {empId:102,employeeName:"Samiksha",employeePrice:22030,employeeDescription:"Angular"},
        {empId:103,employeeName:"Richika",employeePrice:29000,employeeDescription:"Servlets"}
];
    addAll(){
        this.employeedata.push({
            empId:this.empId,
            employeeName:this.employeeName,
            employeePrice:this.employeePrice,
            employeeDescription:this.employeeDescription
        });
    }

    updateOne(dataupdate){
        this.Id=dataupdate.empId;
        this.Name=dataupdate.employeeName;
        this.Price=dataupdate.employeePrice;
        this.Description=dataupdate.employeeDescription;

    }
    update(){
        for(var i=0;i<this.employeedata.length;i++)
        {
            if(this.employeedata[i].empId==this.Id)
            {
                this.employeedata[i].empId=this.Id;
                this.employeedata[i].employeeName=this.Name;
                this.employeedata[i].employeePrice=this.Price;
                this.employeedata[i].employeeDescription=this.Description;
            }
        }

}

delete(data){
    for(var i=0;i<this.employeedata.length;i++)
        {
            if(this.employeedata[i].empId==data.empId)
            {
                this.employeedata.splice(i,1);
            }
        }
}

}