import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.main.html'
})
export class AppComponent {
  
}
