import {Smartphone} from './smartPhone';
import {Basicphone} from './basicPhone';
var arr = new Array();
var basicphn = new Basicphone("Keypad");
arr.push(basicphn);

var smartphn = new Smartphone("Without keypad");
arr.push(smartphn);

for(var i=0;i<arr.length;i++)
{
    arr[i].printMobileDetails();
}

