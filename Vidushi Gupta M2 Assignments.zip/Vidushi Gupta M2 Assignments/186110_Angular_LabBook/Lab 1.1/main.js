"use strict";
exports.__esModule = true;
var smartPhone = require("./smartPhone");
var basicPhone = require("./basicPhone");
var arr = new Array();
var basicphn = new basicPhone.Basicphone("Keypad");
arr.push(basicphn);
var smartphn = new smartPhone.Smartphone("Without keypad");
arr.push(smartphn);
for (var i = 0; i < arr.length; i++) {
    arr[i].printMobileDetails();
}
