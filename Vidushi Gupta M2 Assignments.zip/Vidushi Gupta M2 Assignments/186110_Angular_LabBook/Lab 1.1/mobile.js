"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(mobileId, mobileName, mobileCost) {
        this.mobileId = mobileId;
        this.mobileName = mobileName;
        this.mobileCost = mobileCost;
    }
    Mobile.prototype.printMobileDetails = function () {
        console.log("\n");
        console.log("Mobile ID: " + this.mobileId);
		console.log("Mobile Name: " + this.mobileName);
		console.log("Mobile Cost: " + this.mobileCost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
