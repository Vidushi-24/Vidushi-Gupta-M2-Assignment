export class Mobile{
    mobileId: number;
    mobileName: string;
    mobileCost: number;
    constructor(mobileId,mobileName,mobileCost){
        this.mobileId=mobileId;
        this.mobileName=mobileName;
        this.mobileCost=mobileCost;
    }
    printMobileDetails()
    {   console.log("\n");
        console.log("Mobile ID: " + this.mobileId);
		console.log("Mobile Name: " + this.mobileName);
		console.log("Mobile Cost: " + this.mobileCost);
    }
}