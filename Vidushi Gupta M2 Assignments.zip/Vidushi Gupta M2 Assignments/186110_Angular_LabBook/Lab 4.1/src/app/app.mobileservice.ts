import {Injectable} from '@angular/core';
import {Book} from './mobile';
import {HttpClient} from '@angular/common/http';
@Injectable({
    providedIn:'root'
})

export class BookService{
    constructor(private http:HttpClient){}

    getAllMobileDetail(){
        return this.http.get('assets/booklist.json');
        }
}