import {Component,OnInit} from '@angular/core';
import {Book} from './mobile';
import {BookService} from './app.mobileservice';
@Component({
    selector:'book-app',
    templateUrl:'./mobile.html',
    providers:[BookService]
})
export class BookComponent implements OnInit{
    bookData:Book[];
    click:boolean;
    
constructor(private _mobileservice:BookService){
        }
        ngOnInit(){
        this._mobileservice.getAllMobileDetail().
        subscribe((data:Book[])=>this.bookData=data);
        }
}

