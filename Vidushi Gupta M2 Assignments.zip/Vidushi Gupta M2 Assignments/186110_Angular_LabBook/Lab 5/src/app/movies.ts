export class Movies
{
    name:string;
    rating:number;
    genre:string;
}