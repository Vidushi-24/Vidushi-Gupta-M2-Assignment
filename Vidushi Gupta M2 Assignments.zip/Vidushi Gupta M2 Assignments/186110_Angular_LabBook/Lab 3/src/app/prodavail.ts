export class ProdAvail{
    prodTypeId:number;
    prodTypeName:string;
}